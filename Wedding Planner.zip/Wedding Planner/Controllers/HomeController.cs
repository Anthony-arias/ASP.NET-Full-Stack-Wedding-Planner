﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Wedding_Planner.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;

namespace Wedding_Planner.Controllers
{
    public class AllViewModel
    {
        public List<User> AllUser { get; set; }
        public List<Wedding> AllWeddings { get; set; }
        public User ThisUser { get; set; }
        public Wedding ThisWedding { get; set; }
    }

    public class HomeController : Controller
    {
        private Context _context;
        public HomeController(Context context)
        {
            _context = context;
        }

        // View Routers start here
        [HttpGet("")] // Login Reg Form
        public ViewResult Index()
        {
            return View("Index");
        }

        [HttpGet("dashboard")]
        public ViewResult ViewDashboard()
        {
            List<Wedding> AllWeddings = _context.Weddings
                .Include(wedding => wedding.Attendees)
                .ThenInclude(wedding => wedding.User)
                .ToList();
            TempData["LogedUser"] = (int)HttpContext.Session.GetInt32("CurrentUser");
            return View("Dashboard", AllWeddings);
        }

        [HttpGet("wedding/{id}/info")]
        public ViewResult ViewWeddingInfo(int id)
        {
            Wedding ThisWedding = _context.Weddings
                .Include(wedding => wedding.Attendees)
                .ThenInclude(wedding => wedding.User)
                .FirstOrDefault(wedding => wedding.WeddingId == id);
            return View("WeddingInfo", ThisWedding);
        }

        [HttpGet("wedding/create")]
        public ViewResult ViewWeddingForm()
        {
            TempData["LogedUser"] = (int)HttpContext.Session.GetInt32("CurrentUser");
            return View("WeddingForm");
        }
        // View Routers end here


        // Server Logic starts here
        [HttpGet("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return Redirect("/");
        }

        [HttpPost("user/create")]
        public IActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                if (_context.Users.Any(u => u.Email == user.Email))
                {
                    ModelState.AddModelError("Email", "Email already in use!");
                    return View("Index");
                }
                else
                {
                    PasswordHasher<User> Hasher = new PasswordHasher<User>();
                    user.Password = Hasher.HashPassword(user, user.Password);
                    _context.Add(user);
                    _context.SaveChanges();
                    HttpContext.Session.SetInt32("CurrentUser", user.UserId);
                    return RedirectToAction("ViewDashboard");
                }
            }
            return View("Index");
        }

        [HttpPost("user/login")]
        public IActionResult Login(LoginUser user)
        {
            if (ModelState.IsValid)
            {
                var ThisUser = _context.Users.FirstOrDefault(u => u.Email == user.Email);
                if (ThisUser == null)
                {
                    ModelState.AddModelError("Email", "Invalid Email/Password");
                    return View("Index");
                }

                var hasher = new PasswordHasher<LoginUser>();
                var result = hasher.VerifyHashedPassword(user, ThisUser.Password, user.Password);
                if (result == 0)
                {
                    ModelState.AddModelError("Password", "Invalid Email/Password");
                    return View("Index");
                }
                else
                {
                    HttpContext.Session.SetInt32("CurrentUser", ThisUser.UserId);
                    return RedirectToAction("ViewDashboard");
                }
            }
            return View("Index");
        }

        [HttpPost("wedding/create")]
        public IActionResult CreateWedding(Wedding wedding)
        {
            if(ModelState.IsValid)
            {
                if(wedding.WeddingDate.Date < DateTime.Now.Date)
                {
                    ModelState.AddModelError("WeddingDate", "Wedding must be in the future!");
                    return View("WeddingForm");
                }
                else
                {
                    _context.Add(wedding);
                    _context.SaveChanges();
                    return RedirectToAction("ViewWeddingInfo", new {id = wedding.WeddingId});
                }
            }
            return View("WeddingForm");
        }

        [HttpGet("wedding/addAttendee")]
        public IActionResult AddAttendeeToWedding(int WeddingId, int UserId)
        {
            Console.WriteLine(WeddingId);
            Console.WriteLine(UserId);
            _context.Add(new WeddingUserAssociation{ WeddingId = WeddingId, UserId=UserId });
            _context.SaveChanges();
            return RedirectToAction("ViewDashboard");
        }

        [HttpGet("wedding/removeAttendee")]
        public IActionResult removeAttendeeFromWedding(int WeddingId, int UserId)
        {
            WeddingUserAssociation thisAssociation = _context.WeddingUserAssociation
                .FirstOrDefault(This => This.WeddingId == WeddingId && This.UserId == UserId);

            _context.Remove(thisAssociation);
            _context.SaveChanges();
            return RedirectToAction("ViewDashboard");
        }

        [HttpGet("wedding/delete")]
        public IActionResult RemoveWedding(int WeddingId)
        {
            Wedding ThisWedding = _context.Weddings
                .FirstOrDefault(wedding => wedding.WeddingId == WeddingId);

            _context.Remove(ThisWedding);
            _context.SaveChanges();
            return RedirectToAction("ViewDashboard");
        }
        // Server Logic ends here
    }
}
